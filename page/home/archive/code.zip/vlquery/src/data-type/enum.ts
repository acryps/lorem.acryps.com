import { BaseDataType } from "./base";

export class Enum extends BaseDataType {}