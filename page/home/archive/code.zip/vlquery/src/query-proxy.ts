import { QueryUUID } from ".";

export class QueryProxy {
	id: QueryUUID & string & number;
}

export class QueryType {}
