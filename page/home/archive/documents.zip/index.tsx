import { Component } from "vldom";

import email from 'url:./email.eml';

export class DocumentComponent extends Component {
	render() {
		files = [
			email
		];

		return <ui-data-samples>
			<ui-title>Document Samples</ui-title>

			<ui-files>
				{files.map(file => <ui-file ui-href={file}>
					{file}
				</ui-file>)}
			</ui-files>
		</ui-data-samples>;
	}
}